import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import javax.crypto.*;
import javax.crypto.spec.SecretKeySpec;
//import java.security.*
public class SessionKey {
    SecretKey key;
    byte[] keybytes;
    SessionKey (Integer keylength) throws NoSuchAlgorithmException {

       SecureRandom secureRNDM = new SecureRandom(); 
       KeyGenerator keyGNR =  KeyGenerator.getInstance("AES");
       keyGNR.init(keylength, secureRNDM) ;
       key = keyGNR.generateKey();
    }
    SecretKey getSecretKey() {
    return key;
    }
    public byte[] getKeyBytes() {
    byte [] tobytes = getSecretKey().getEncoded();
    return tobytes;
    }
    SessionKey (byte[] keybytes){
        key = new SecretKeySpec(keybytes,"AES");

    }
}