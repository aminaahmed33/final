import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PublicKey;
import java.security.SignatureException;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;


public class VerifyCertificate {

private static final PublicKey PublicKey = null;
/**
 * Copied and modified from different internet sources:
 * http://www.java2s.com/example/java/security/load-certificate-from-file.html
 * https://www.tabnine.com/code/java/classes/java.security.cert.X509Certificate
 * http://www.java2s.com/example/java-api/java/security/cert/x509certificate/checkvalidity-0-2.html
 * https://stackoverflow.com/questions/2914521/how-to-extract-cn-from-x509certificate-in-java
 * https://stackoverflow.com/questions/3389143/generate-x509certificate-from-byte
 */
   public static void main(String[] args) throws CertificateException, IOException, InvalidKeyException, NoSuchAlgorithmException, NoSuchProviderException, SignatureException{
    verification(args[0], args[1]);
   }
public static void verification(String CAfile, String userfile) throws CertificateException, InvalidKeyException, NoSuchAlgorithmException, NoSuchProviderException, SignatureException, IOException {
    X509Certificate cacert =  getCertificate(CAfile);
    X509Certificate usercert =  getCertificate(userfile);
    System.out.println("DN for the CA"+cacert.getSubjectX500Principal().getName());
    System.out.println("DN for the user"+usercert.getSubjectX500Principal().getName());
        try {
            cacert.verify(cacert.getPublicKey());
            cacert.checkValidity();
            usercert.verify(cacert.getPublicKey());
            usercert.checkValidity();
            System.out.println("Verification Passed");
        } catch (Exception e) {
            System.out.println("Verification Failed"+e.getMessage());
        }
        getpublickey (cacert);
        getpublickey (usercert);
}
public static void verificationVpnCert(String CAfile, byte [] userfile) throws CertificateException, InvalidKeyException, NoSuchAlgorithmException, NoSuchProviderException, SignatureException, IOException {
    X509Certificate cacert =  getCertificate(CAfile);
    X509Certificate usercert =  getFromByteCertificate(userfile);
    System.out.println("DN for the CA"+cacert.getSubjectX500Principal().getName());
    System.out.println("DN for the user"+usercert.getSubjectX500Principal().getName());
        try {
            cacert.verify(cacert.getPublicKey());
            cacert.checkValidity();
            usercert.verify(cacert.getPublicKey());
            usercert.checkValidity();
            System.out.println("Verification Passed");
        } catch (Exception e) {
            System.out.println("Verification Failed"+e.getMessage());
        }
        getpublickey (cacert);
        getpublickey (usercert);
    }
public static X509Certificate getCertificate(String certfile) throws CertificateException, IOException {
CertificateFactory cerfc = CertificateFactory.getInstance("X.509");
FileInputStream fin = new FileInputStream(certfile);
java.security.cert.Certificate certificate = cerfc.generateCertificate(fin);
fin.close();
return (X509Certificate) certificate;
}

public static X509Certificate getFromByteCertificate(byte[] certfile) throws CertificateException, IOException {
    CertificateFactory cerfc = CertificateFactory.getInstance("X.509");
    InputStream fin = new ByteArrayInputStream(certfile);
    java.security.cert.Certificate certificate = cerfc.generateCertificate(fin);
    fin.close();
    return (X509Certificate) certificate;
    }
public static PublicKey getpublickey (X509Certificate certificate){
    certificate.getPublicKey();
return PublicKey;
}
}
