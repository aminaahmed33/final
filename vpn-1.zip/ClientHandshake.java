/**
 * Client side of the handshake.
 */

import java.net.Socket;
import java.security.PrivateKey;
import java.security.cert.X509Certificate;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Base64.Encoder;
import java.io.IOException;

/* Studied, copied and modified from different internet sources:
https://stackabuse.com/encoding-and-decoding-base64-strings-in-java/
https://stackoverflow.com/questions/1075895/how-can-i-catch-all-the-exceptions-that-will-be-thrown-through-reading-and-writi
https://docs.oracle.com/javase/8/docs/api/java/util/Base64.html 
https://www.freecodecamp.org/news/java-string-to-int-how-to-convert-a-string-to-an-integer/
https://github.com/
*/

public class ClientHandshake {
    /*
     * The parameters below should be learned by the client
     * through the handshake protocol. 
     */
    
    /* Session host/port  */
    public static String sessionHost = "localhost";
    public static int sessionPort = 12345;    
    X509Certificate clientCert;
    X509Certificate serverCert;
    PrivateKey clientPriKey;

    /* Security parameters key/iv should also go here. Fill in! */
     byte [] sessionKey;
     byte [] sessionIV;
    /**
     * Run client handshake protocol on a handshake socket. 
     * Here, we do nothing, for now.
     */ 
    public ClientHandshake(Socket handshakeSocket) throws IOException {
    }
    public void clientHello (Socket socket, String clientcert){
    	HandshakeMessage clientHello = new HandshakeMessage();
    	try {
    		clientCert = VerifyCertificate.getCertificate(clientcert);
            Encoder encoder = Base64.getEncoder();
        	String clientCertString = encoder.encodeToString(clientCert.getEncoded());
        	clientHello.putParameter("MessageType","ClientHello");
        	clientHello.putParameter("Certificate",clientCertString);
        	clientHello.send(socket);
			Logger.log("ClientHello sent successfully");
		} catch (Exception e) {
			e.printStackTrace();
			Logger.log("ClientHello failed");
		}
    }
    
    public void recServerHello (Socket socket, String cecert) {
    	HandshakeMessage recServerHello = new HandshakeMessage();
    	try {
    		recServerHello.recv(socket);
			if (recServerHello.getParameter("MessageType").equals("ServerHello")) {
				String serverCertString = recServerHello.getParameter("Certificate");
                Decoder decoder = Base64.getDecoder();
				byte[] serverCertByte = decoder.decode(serverCertString);
				VerifyCertificate.verificationVpnCert(cecert, serverCertByte);
				Logger.log("verification of server certificate is successful!");
			} else {
				throw new Exception();
			}
			Logger.log("ServerHello reveived successfully");
		} catch (Exception e) {
			e.printStackTrace();
			Logger.log("ServerHello not received");
		}
    }
    
    public void forward (Socket socket, String targetHost, String targetPort) throws IOException {
    	HandshakeMessage forward = new HandshakeMessage();
    	forward.putParameter("MessageType","Forward");
    	forward.putParameter("TargetHost",targetHost);
    	forward.putParameter("TargetPort",targetPort);
    	
		forward.send(socket);
            try {
			Logger.log("Forward sent");
		} catch (Exception e) {
			e.printStackTrace();
			Logger.log("Forwared failed");
		}	
    }
    
    public void recSession (Socket socket, String key) {
    	HandshakeMessage recSession = new HandshakeMessage();
    	try {
			recSession.recv(socket);
			if (recSession.getParameter("MessageType").equals("Session")) {
				PrivateKey clientPriKey = HandshakeCrypto.getPrivateKeyFromKeyFile(key);
                String obtSessionKey = recSession.getParameter("SessionKey");
                String obtSessionIV = recSession.getParameter("SessionIV");
                byte[] decSessionKey = Base64.getDecoder().decode(obtSessionKey);
                byte[] decSessionIV = Base64.getDecoder().decode(obtSessionIV);
				sessionKey = HandshakeCrypto.decrypt (decSessionKey, clientPriKey);
				sessionIV = HandshakeCrypto.decrypt(decSessionIV, clientPriKey);
				sessionHost = recSession.getParameter("SessionHost");
				sessionPort = Integer.valueOf(recSession.getParameter("SessionPort"));
				Logger.log("Session message received!");
            } else {
				throw new Exception();
			}
			Logger.log("ServerHello reveived successfully");
		} catch (Exception e) {
			e.printStackTrace();
			Logger.log("ServerHello not received");
		}
    }
}
