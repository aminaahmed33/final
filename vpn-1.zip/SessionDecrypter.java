import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import java.io.InputStream;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

/**
     * Copied and modified from different Internet Sources,
     * https://www.mkammerer.de/blog/aes-ctr-encryption-with-java/
     * https://stackoverflow.com/questions/29575024/is-there-any-difference-if-i-init-aes-cipher-with-and-without-ivparameterspec
     * https://www.tabnine.com/code/java/classes/javax.crypto.CipherOutputStream
     * https://stackoverflow.com/questions/53448949/how-do-i-retrieve-an-ivparameterspec-after-base64-decode
     */

public class SessionDecrypter {
    public SessionKey sessionKey;
    IvParameterSpec Ivparameter;
    Cipher cipher;
    byte[] decodedIV;


    public SessionDecrypter(byte[] KEYBYTES, byte[] IVBYTES) throws Exception{
        sessionKey = new SessionKey(KEYBYTES);
        decodedIV = IVBYTES;
        try {
            cipher = Cipher.getInstance("AES/CTR/NoPadding");
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (NoSuchPaddingException e) {
            e.printStackTrace();
        }
        Ivparameter = new IvParameterSpec(decodedIV);
        try {
            this.cipher.init(Cipher.DECRYPT_MODE, sessionKey.getSecretKey(), Ivparameter);
        } catch (InvalidKeyException e) {
            e.printStackTrace();
        } catch (InvalidAlgorithmParameterException e) {
            e.printStackTrace();
        }
    }
    public CipherInputStream openCipherInputStream(InputStream input) {
        try {
            cipher = Cipher.getInstance("AES/CTR/NoPadding");
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (NoSuchPaddingException e) {
            e.printStackTrace();
        }
        IvParameterSpec ivParameterSpec = new IvParameterSpec(decodedIV);
        try {
            cipher.init(Cipher.DECRYPT_MODE, sessionKey.getSecretKey(), ivParameterSpec);
        } catch (InvalidKeyException e) {
            e.printStackTrace();
        } catch (InvalidAlgorithmParameterException e) {
            e.printStackTrace();
        }
        return new CipherInputStream(input, cipher);
}
}