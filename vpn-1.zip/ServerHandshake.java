/**
 * Server side of the handshake.
 */

import java.net.InetAddress;
import java.net.Socket;
import java.security.PublicKey;
import java.security.cert.X509Certificate;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.net.ServerSocket;
import java.io.IOException;

/* Studied, copied and modified from different internet sources:
https://stackabuse.com/encoding-and-decoding-base64-strings-in-java/
https://stackoverflow.com/questions/1075895/how-can-i-catch-all-the-exceptions-that-will-be-thrown-through-reading-and-writi
https://docs.oracle.com/javase/8/docs/api/java/util/Base64.html 
https://www.freecodecamp.org/news/java-string-to-int-how-to-convert-a-string-to-an-integer/
https://www.javatpoint.com/java-int-to-string 
https://github.com */


public class ServerHandshake {
    /*
     * The parameters below should be learned by the server
     * through the handshake protocol. 
     */
    
    /* Session host/port, and the corresponding ServerSocket  */
    public static ServerSocket sessionSocket;
    public static String sessionHost;
    public static int sessionPort;
    X509Certificate serverCertificate; 
    X509Certificate clientCert;
    X509Certificate caCert;

    /* The final destination -- simulate handshake with constants */
    public static String targetHost = "localhost";
    public static int targetPort = 6789;


    /* Security parameters key/iv should also go here. Fill in! */
    byte [] sessionKey;
    byte [] sessionIV;
    /**
     * Run server handshake protocol on a handshake socket. 
     * Here, we simulate the handshake by just creating a new socket
     * with a preassigned port number for the session.
     */ 
    public ServerHandshake(Socket handshakeSocket) throws IOException {
        sessionSocket = new ServerSocket(sessionPort);
        sessionHost = sessionSocket.getInetAddress().getHostName();
        sessionPort = sessionSocket.getLocalPort();
    }
    public void recClientHello (Socket socket, String cacert) {
    	HandshakeMessage recClientHello = new HandshakeMessage();
    	try {
    		recClientHello.recv(socket);
			if (recClientHello.getParameter("MessageType").equals("ClientHello")) {
				String clientCertString = recClientHello.getParameter("Certificate");
                Decoder decoder = Base64.getDecoder();
				byte[] clientCertByte = decoder.decode(clientCertString);
                clientCert = VerifyCertificate.getFromByteCertificate(clientCertByte);
				VerifyCertificate.verificationVpnCert(cacert, clientCertByte);
				Logger.log("verification of client certificate passed successfully");
			} else {
				throw new Exception();
			}
			Logger.log("ClientHello reveived successfully");
		} catch (Exception e) {
			e.printStackTrace();
			Logger.log("ClientHello not received");
		}
    }
    
    public void serverHello (Socket socket, String certificatePath) {
    	HandshakeMessage serverHello = new HandshakeMessage();
    	try {
    		serverCertificate = VerifyCertificate.getCertificate(certificatePath);
            java.util.Base64.Encoder encoder = Base64.getEncoder();
        	String serverCertString = encoder.encodeToString(serverCertificate.getEncoded());
        	serverHello.putParameter("MessageType","ServerHello");
        	serverHello.putParameter("Certificate",serverCertString);
        	serverHello.send(socket);
			Logger.log("ServerHello sent successfully");
		} catch (Exception e) {
			e.printStackTrace();
			Logger.log("ServerHello failed");
		}
    }
    
    public void recForward (Socket socket) {
    	HandshakeMessage recForward = new HandshakeMessage();
    	try {
			recForward.recv(socket);
			if (recForward.getParameter("MessageType").equals("Forward")) {
				targetHost = recForward.getParameter("TargetHost");
				targetPort = Integer.parseInt(recForward.getParameter("TargetPort"));
				Logger.log("forward received");
			} else {
				throw new Exception();
			}
		} catch (Exception e) {
			e.printStackTrace();
			Logger.log("forwared not received");
		}
    }
    
    public void session (Socket socket) {
    	HandshakeMessage session = new HandshakeMessage();
    	session.putParameter("MessageType","Session");
    	PublicKey clientPubKey = clientCert.getPublicKey();
    	try {
			SessionEncrypter encrypt = new SessionEncrypter(128);
			sessionKey = encrypt.getKeyBytes();
			sessionIV = encrypt.getIVBytes();
			byte[] encSessionKey =  HandshakeCrypto.encrypt(sessionKey, clientPubKey);
			byte[] encsessionIV = HandshakeCrypto.encrypt(sessionIV, clientPubKey);
            String encodedSessionKey = Base64.getEncoder().encodeToString(encSessionKey);
            String encodedSessionIV = Base64.getEncoder().encodeToString(encsessionIV);
            String intSessionPort = Integer.toString(sessionPort);
			session.putParameter("MessageType", "Session");
			session.putParameter("SessionKey", encodedSessionKey);
			session.putParameter("SessionIV", encodedSessionIV);
			session.putParameter("SessionHost", sessionHost);
			session.putParameter("SessionPort", intSessionPort);
			session.send(socket);	
			Logger.log("Session sent successfully");
		} catch (Exception e) {
			e.printStackTrace();
			Logger.log("Session failed");
		}
    }
}
