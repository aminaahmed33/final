import java.io.OutputStream;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import javax.crypto.*;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
public class SessionEncrypter {
    IvParameterSpec iv;
    byte[] cipherText;
    Cipher cipher;
    SessionKey key;
    public SecretKey sessionkey;
    public byte[] IV_byte = null;
    SecretKey key1;
    

/**
     * Copied and modified from different Internet Sources,
     * https://www.mkammerer.de/blog/aes-ctr-encryption-with-java/
     * https://stackoverflow.com/questions/29575024/is-there-any-difference-if-i-init-aes-cipher-with-and-without-ivparameterspec
     * https://www.tabnine.com/code/java/classes/javax.crypto.CipherOutputStream
     */

    public SessionEncrypter(Integer keylength)throws Exception {
      
        key = new SessionKey(keylength);
        SecretKey secret = key.getSecretKey();
        byte[] inVEC = new byte[16];
        new SecureRandom().nextBytes(inVEC);
        iv = new IvParameterSpec(inVEC);
        Cipher cipher = Cipher.getInstance("AES/CTR/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE, secret, iv);
        cipher.doFinal();

    }
    public SessionEncrypter(byte[] KEYBYTES, byte[] IVBYTES)throws Exception{
        key1 = new SecretKeySpec (KEYBYTES,"AES");
        iv = new IvParameterSpec(IVBYTES);
        Cipher cipher = Cipher.getInstance("AES/CTR/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE, key1, iv);
        cipher.doFinal();

    }
    CipherOutputStream openCipherOutputStream(OutputStream output)throws Exception{
        cipher = Cipher.getInstance("AES/CTR/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE, key1, iv);
        return  new CipherOutputStream(output, cipher);

    }
    public byte[] getKeyBytes(){
        return key.getKeyBytes();
    }
    public byte[] getIVBytes(){
        return iv.getIV();
    }
}
